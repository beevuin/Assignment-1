import 'dart:io';

void getUserInfo() {
  stdout.write("Please enter your name: ");
  String name = stdin.readLineSync()!;

  stdout.write("Please enter your surname: ");
  String surname = stdin.readLineSync()!;

  stdout.write("Please enter your year of birth: ");
  int yearOfBirth = int.parse(stdin.readLineSync()!);

  int currentYear = DateTime.now().year;
  int age = currentYear - yearOfBirth;

  print("Thank you for providing your information.");
  print("Name: $name");
  print("Surname: $surname");
  print("Year of Birth: $yearOfBirth");
  print("Age: $age");
}

void main() {
  getUserInfo();
}
