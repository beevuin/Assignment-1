import 'dart:io';

void getUserInfo() {
  stdout.write("Please enter your name: ");
  String name = stdin.readLineSync()!;

  stdout.write("Please enter your surname: ");
  String surname = stdin.readLineSync()!;

  stdout.write("Please enter the faculty you are studying: ");
  String faculty = stdin.readLineSync()!;

  print("Thank you for providing your information.");
  print("Name: $name");
  print("Surname: $surname");
  print("Faculty: $faculty");
}

void main() {
  getUserInfo();
}
